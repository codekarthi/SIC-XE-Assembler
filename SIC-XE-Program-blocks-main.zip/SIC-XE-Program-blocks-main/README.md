# SIC-XE-Program-blocks

## This is the project for CSN-252

## The project is about converting  code to the object program.
## This take code as the input and gives the following as output
## 1.	Object program.
## 2.	Errors If any
## 3.	Listing files
## 4.	Tables.
## 5.	Intermediate file.
## The following is the procedure for the running of code
###  1.	Download the zip folder and open in the editor.
###  2.	Open the terminal and run the codes: g++ p2.cpp
###                                          . \a.exe
###  3.	Enter the input file. Here we already taken a sample input.Run the code
